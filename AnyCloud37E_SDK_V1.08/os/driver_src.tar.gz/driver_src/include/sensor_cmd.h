#ifndef __SENSOR_CMD_H__
#define __SENSOR_CMD_H__

enum sensor_cmd {
	SENSOR_GET_ID = 0x910000 | 0x1,
};

#endif
