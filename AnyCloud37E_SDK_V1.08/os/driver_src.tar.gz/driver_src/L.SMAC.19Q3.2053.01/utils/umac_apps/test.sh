./icomm_osif_hal_util pattern_test pattern/HCI_RX.bin
./icomm_osif_hal_util pattern_test pattern/HCI_TX_8WSID.bin
./icomm_osif_hal_util pattern_test pattern/HCI_TX_M0_80211.bin
./icomm_osif_hal_util pattern_test pattern/HCI_TX_M0_8023.bin
./icomm_osif_hal_util pattern_test pattern/HCI_TX_M1_80211.bin
./icomm_osif_hal_util pattern_test pattern/HCI_TX_M1_8023.bin

./icomm_osif_hal_util pattern_test pattern/HWSEC_V2_AMPDU_V2.bin
./icomm_osif_hal_util pattern_test pattern/HWSEC_V2_AMPDU_V2_FIX_PN.bin
./icomm_osif_hal_util pattern_test pattern/HWSEC_V2_CCMP_FIX_PN.bin
./icomm_osif_hal_util pattern_test pattern/HWSEC_V2_GROUP.bin
./icomm_osif_hal_util pattern_test pattern/HWSEC_V2_TEST.bin

./icomm_osif_hal_util pattern_test pattern/MRX_ACK_GEN.bin
./icomm_osif_hal_util pattern_test pattern/MRX_AMPDU_RX.bin
./icomm_osif_hal_util pattern_test pattern/MRX_DECISION_FLOW.bin
./icomm_osif_hal_util pattern_test pattern/MRX_FILTER_TABLE.bin
./icomm_osif_hal_util pattern_test pattern/MRX_MCAST_TABLE.bin
./icomm_osif_hal_util pattern_test pattern/MRX_MIB_COUNTER.bin
./icomm_osif_hal_util pattern_test pattern/MRX_TRAP_REASON.bin
./icomm_osif_hal_util pattern_test pattern/MRX_BA_SCORE_BOARD.bin
./icomm_osif_hal_util pattern_test pattern/MRX_TIMESTAMP.bin

./icomm_osif_hal_util pattern_test pattern/MTX_AMPDU_RETRY_CNT.bin
./icomm_osif_hal_util pattern_test pattern/MTX_AMPDU_V2.bin
./icomm_osif_hal_util pattern_test pattern/MTX_AMPDU_V3.bin
./icomm_osif_hal_util pattern_test pattern/MTX_RATE_MPDU.bin
./icomm_osif_hal_util pattern_test pattern/MTX_RETRY_CNT.bin
./icomm_osif_hal_util pattern_test pattern/MTX_RETRY_CNT_CTS2SELF.bin
#./icomm_osif_hal_util pattern_test pattern/MTX_TXQ_ON_OFF.bin
# for mp
./icomm_osif_hal_util pattern_test pattern/MTX_TXQ_ON_OFF_MP.bin
