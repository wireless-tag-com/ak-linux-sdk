#ifndef _SSV_VERSION_H_
#define _SSV_VERSION_H_

static u32 ssv_root_version = 7338;

#define SSV_ROOT_URl "http://10.10.20.22/svn/wifi/host/SMAC/branch/L.SMAC.19Q3.0000.00"
#define COMPILERHOST "twbcsrv1"
#define COMPILERDATE "12-29-2020-16:29:22"
#define COMPILEROS "linux"
#define COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

