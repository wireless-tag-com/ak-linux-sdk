readme

1. modify toolchain in config.mk

2. build user_smartlink
   source env.sh
   make clean;make

3. if you change it, please refer to user_smartlink.c
