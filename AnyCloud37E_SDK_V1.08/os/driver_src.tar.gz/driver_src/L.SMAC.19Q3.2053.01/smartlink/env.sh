export PATH=$PATH:/opt/arm-anykav200-crosstool/usr/bin
