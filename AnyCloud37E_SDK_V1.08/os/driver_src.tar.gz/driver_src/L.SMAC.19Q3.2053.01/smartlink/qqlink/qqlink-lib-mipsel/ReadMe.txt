腾讯 QQ 物联设备SDK能够嵌入到arm-linux平台、mips-linux平台和RTOS平台，提供音视频能力，消息能力和控制信令能力。将设备注册到QQ平台后，QQ用户就能够用手机和设备进行音视频通话，发送消息和触发控制信令等。

更多信息可以访问 QQ物联资料库 网址：
http://iot.open.qq.com/wiki/index.html#!CASE/IP_Camera.md

SDK 下载页面网址：
http://iot.open.qq.com/wiki/index.html#!SDK/Linux.md
