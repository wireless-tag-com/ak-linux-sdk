#/bin/bash

rmmod ssv6x5x

rmmod mmc_core
rmmod mmc_block

rmmod sdhci
rmmod sdhci_pci

